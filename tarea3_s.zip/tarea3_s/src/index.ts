import express from 'express';
import fileRoutes from './routes/fileRoutes';
import path from 'path';
import fs from 'fs';

const app = express();
const PORT = 3000;

// Verifica si la carpeta "documents" existe, si no, la crea
const documentsDir = path.join(__dirname, '../documents');
if (!fs.existsSync(documentsDir)) {
  fs.mkdirSync(documentsDir, { recursive: true });
}

// Middleware para parsear el cuerpo de las peticiones como JSON
app.use(express.json());

// Utiliza las rutas definidas en fileRoutes
app.use(fileRoutes);

// Inicia el servidor en el puerto 3000
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
