import { Router } from 'express';
import { uploadFile, downloadFile } from '../controllers/fileController';
import { upload } from '../config/multerConfig';

const router = Router();

// Ruta para subir archivos PDF
// Usa el middleware de Multer para permitir la carga de múltiples archivos (hasta 10 en este caso)
router.post('/uploads', upload.array('docs', 10), uploadFile);

// Ruta para descargar un archivo PDF basado en su nombre proporcionado en la query string
router.get('/download', downloadFile);

export default router;
