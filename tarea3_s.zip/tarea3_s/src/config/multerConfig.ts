import multer from 'multer';
import path from 'path';

// Configuración de almacenamiento para Multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, '../../documents')); // Define la carpeta "documents" como destino
  },
  filename: (req, file, cb) => {
    // Renombra el archivo para evitar conflictos de nombres, añade timestamp
    const uniqueSuffix = `${Date.now()}-${file.originalname}`;
    cb(null, uniqueSuffix);
  }
});

// Filtro para permitir solo archivos PDF
const fileFilter = (req: Express.Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  if (file.mimetype === 'application/pdf') {
    cb(null, true); // Acepta el archivo
  } else {
    cb(new Error('Only PDF files are allowed')); // Rechaza archivos que no sean PDFs
  }
};

// Configuración de Multer con el almacenamiento y el filtro
export const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 10 * 1024 * 1024 // Límite de tamaño de archivo (10 MB)
  }
});
