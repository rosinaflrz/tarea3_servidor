import { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';

// Controlador para subir archivos
export const uploadFile = (req: Request, res: Response) => {
  // Verifica si se han subido archivos
  if (!req.files || (req.files as Express.Multer.File[]).length === 0) {
    return res.status(400).json({ message: 'No files were uploaded' });
  }

  // Si los archivos fueron subidos correctamente, devuelve la información de cada archivo
  const files = req.files as Express.Multer.File[];
  const fileData = files.map(file => ({
    originalName: file.originalname,
    fileName: file.filename,
    size: file.size,
    path: file.path
  }));

  res.status(200).json({
    message: 'Files uploaded successfully',
    files: fileData
  });
};

// Controlador para descargar archivos
export const downloadFile = (req: Request, res: Response) => {
  const fileName = req.query.file as string;

  // Verifica si el nombre del archivo fue proporcionado
  if (!fileName) {
    return res.status(400).json({ message: 'File name is required' });
  }

  // Construye la ruta del archivo dentro de la carpeta "documents"
  const filePath = path.join(__dirname, '../../documents', fileName);

  // Verifica si el archivo existe en el sistema de archivos
  if (fs.existsSync(filePath)) {
    // Si el archivo existe, lo envía como respuesta para su descarga
    res.download(filePath, (err) => {
      if (err) {
        return res.status(500).json({ message: 'Error downloading file', error: err.message });
      }
    });
  } else {
    // Si el archivo no existe, responde con un error 404
    res.status(404).json({ message: 'File not found' });
  }
};
